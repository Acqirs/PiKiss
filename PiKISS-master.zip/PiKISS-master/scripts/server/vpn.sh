#!/bin/bash
#
# Description : Install VPN Server by Mohamad (https://www.boynux.com)
# Author      : Jose Cerrejon Gonzalez (ulysess@gmail_dot._com)
# Version     : 0.1 (24/May/14)
#
# TODO        · https://www.boynux.com/raspberry-pi-vpn-server/
#
clear

