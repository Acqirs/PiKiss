#!/bin/bash
#
# Description : Install HotSpot thks to https://www.pihomeserver.fr
# Author      : Jose Cerrejon Gonzalez (ulysess@gmail_dot._com)
# Version     : 0.1 (24/May/14)
#
# TODO        · https://www.pihomeserver.fr/en/2014/05/22/raspberry-pi-home-server-creer-hot-spot-wifi-captive-portal/
#
clear
