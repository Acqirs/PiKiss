#!/bin/bash
#
# Description : Turn Raspberry Pi into a Wireless Access Point (AP)
# Author      : Jose Cerrejon Gonzalez (ulysess@gmail_dot._com)
# Version     : 0.1
#
# HELP        · https://www.rpiblog.com/2012/12/turn-raspberry-pi-into-wireless-access.html
#             · https://www.novitiate.co.uk/?p=183
clear

