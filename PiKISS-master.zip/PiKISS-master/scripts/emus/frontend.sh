#!/bin/bash
#
# Description : Compile AdvanceMENU, EmulationStation, RetroArch
# Author      : Jose Cerrejon Gonzalez (ulysess@gmail_dot._com)
# Version     : 0.1
#
# HELP        · https://www.raspberrypi.org/forums/viewtopic.php?f=78&t=79663
#             · https://www.raspberrypi.org/forums/viewtopic.php?f=78&t=13552
#             · https://www.raspberrypi.org/forums/viewtopic.php?f=78&t=56070
clear
